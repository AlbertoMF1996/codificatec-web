LISTOFACTURA - ESTRUCTURA WEB

Copia el contenido de esta carpeta en la raíz pública actual de codificatec.es.

Estructura esperada:

/
├── index.html
├── robots.txt
├── sitemap.xml
├── programa-facturacion/index.html
├── verifactu/index.html
├── autonomos/index.html
├── pymes/index.html
├── funcionalidades/index.html
├── precios/index.html
├── descargar/index.html
├── guias/index.html
├── avisos-legales/index.html
├── terminos/index.html
└── assets/
    ├── css/styles.css
    ├── js/main.js
    └── img/  <-- CONSERVA AQUÍ TUS IMÁGENES ACTUALES

IMPORTANTE:
- No borres assets/img de la web actual.
- El ZIP generado no incluye las imágenes porque no fueron adjuntadas.
- Sustituye el CSS y JS actuales por los incluidos.
- Añade las reglas de nginx-listofactura.conf.snippet al bloque server de codificatec.es.
- Comprueba nginx con: sudo nginx -t
- Después recarga: sudo systemctl reload nginx
